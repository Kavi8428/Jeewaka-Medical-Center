<?php
// Database connection
include '../connection.php';

// Retrieve and process row-specific data from the POST request
$jsonData = $_POST['mediDataArray'];
$mediDataArray = json_decode($jsonData, true);

// Loop through each row data and update or insert the corresponding record in the database
foreach ($mediDataArray as $rowData) {
    $name = $rowData['name'];
    $mediName = $rowData['generic'];
    $retailerP = $rowData['retailerP'];
    $totalRI = $rowData['totalRI'];

    // Debugging: Output values of variables
    echo "Company: " . $name . "<br>";
    echo "Medicine Name: " . $mediName . "<br>";
    echo "Retailer Price: " . $retailerP . "<br>";
    echo "Total RI: " . $totalRI . "<br>";

    // Update row-specific data in the 'medicines' table
    $sql = "UPDATE medicines SET cost = '$retailerP', qt = COALESCE(qt, 0) + '$totalRI' WHERE name='$name' AND mediName='$mediName'";
    
    // Debugging: Output SQL query
    echo "SQL Query: " . $sql . "<br>";

    if ($conn->query($sql) === FALSE) {
        // Debugging: Output error message if query fails
        echo "Error updating row-specific data: " . $conn->error . "<br>";
    } else {
        echo "Data updated successfully for $name ($mediName)<br>";
    }
}

$conn->close();
?>
