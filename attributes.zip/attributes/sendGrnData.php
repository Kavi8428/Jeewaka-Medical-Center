<?php
// Database connection
include '../connection.php';

// Retrieve general data from the POST request
//$mediRep = $_POST['mediRep'];
$invoice = $_POST['invoice'];
$supplier = $_POST['supplier'];
//$serial = $_POST['serial'];
$status = $_POST['status'];


// Insert general data into 'grn' table only once
$sql = "INSERT INTO grn (ivNumber, company, status) VALUES ( '$invoice', '$supplier', '$status')";
if ($conn->query($sql) === FALSE) {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Get the last inserted ID (GRN ID)
$grnID = $conn->insert_id;

// Retrieve and process row-specific data from the POST request
$jsonData = $_POST['formDataArray'];
$formDataArray = json_decode($jsonData, true);

// Loop through each row data and insert into the database
foreach ($formDataArray as $rowData) {
    $name = $rowData['name'];
    $generic = $rowData['generic'];
    $mrn = $rowData['mrn'];
    $expiryDate = $rowData['ex'];
    $tc = $rowData['tc'];
    $pSize = $rowData['pSize'];
    $pQt = $rowData['pQT'];
    $totalI = $rowData['totalI'];
    $pricePI = $rowData['pricePI'];
    $pricePP = $rowData['pricePP'];
    $retailerP = $rowData['retailerP'];
    $sp = $rowData['sp'];
    $bBonus = floatval($rowData['bBonus']);
    $bBP = $rowData['bBP'];
    $mrBonus = floatval($rowData['mrBonus']);
    $mrBP = $rowData['mrBP'];
    $totalRI = $rowData['totalRI'];
    $costPI = $rowData['costPI'];
    $profit = $rowData['profit'];

    // Insert row-specific data into 'grnproducts' table for each row
    $sql2 = "INSERT INTO grnproducts (grnNo, name, generic, mediRep,  expiryDate, tc, pSize, pQt, totalItems, pricePI, pricePP, retailP, sp,  billBonus, bBP,  mrBonus, mrBP, totalRI, costPI, profit) VALUES ('$grnID', '$name', '$generic', '$mrn', '$expiryDate', '$tc', '$pSize', '$pQt', '$totalI', '$pricePI', '$pricePP', '$retailerP', '$sp',  '$bBonus','$bBP','$mrBonus', '$mrBP', '$totalRI', '$costPI', '$profit')";
    if ($conn->query($sql2) === FALSE) {
        echo "Error: " . $sql2 . "<br>" . $conn->error;
    }

    
}

$conn->close();
?>
